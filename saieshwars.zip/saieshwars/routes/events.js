const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const jwt = require('jsonwebtoken');
// Events Page
// Events Page
router.get('/', async (req, res) => {
  const { location, category, date } = req.query;

  const filter = {};
  if (location) filter.location = location;
  if (category) filter.category = category;
  if (date) filter.date = date;

  let userEmail = null;

  try {
    const token = req.cookies.token;
    if (token) {
      const decoded = jwt.verify(token, 'secretkey');
      userEmail = decoded.email;
    }
  } catch (err) {
    // ignore JWT errors for public access
  }

  try {
    const events = await Event.find(filter);
    res.render('events', { events, userEmail }); // ✅ userEmail passed here
  } catch (err) {
    res.status(500).send('Failed to load events');
  }
});

router.get('/:id', async (req, res) => {
  let userEmail = null;

  // Check if there's a token and decode it
  try {
    const token = req.cookies.token;
    if (token) {
      const decoded = jwt.verify(token, 'secretkey'); // Ensure to use your actual secret key here
      userEmail = decoded.email;
    }
  } catch (err) {
    // ignore JWT errors for public access
  }

  try {
    const eventId = req.params.id;
    const event = await Event.findById(eventId);

    if (!event) {
      return res.status(404).send('Event not found');
    }

    // Render the event details page and pass the event and userEmail
    res.render('event-details', { event, userEmail });
  } catch (err) {
    console.error('Error fetching event details:', err);
    res.status(500).send('Server Error');
  }
});
// RSVP Submission (Optional - basic version)
router.post('/rsvp', (req, res) => {
  const { name, email, event } = req.body;
  console.log(`RSVP received from ${name} for event ${event}`);
  res.send("RSVP received!");
});

module.exports = router;
