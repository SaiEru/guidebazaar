const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const Blog = require('../models/Blog');
const nodemailer = require('nodemailer');

// Home Page
router.get('/', async (req, res) => {
  const events = await Event.find().sort({ date: 1 }).limit(3);
  res.render('home', { events });
});

// Contact form
router.post('/contact', async (req, res) => {
  const { name, email, message } = req.body;

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS
    }
  });

  const mailOptions = {
    from: email,
    to: process.env.EMAIL_USER,
    subject: `New message from ${name}`,
    text: message
  };

  try {
    await transporter.sendMail(mailOptions);
    res.send('Message sent successfully!');
  } catch (err) {
    console.error(err);
    res.send('Error sending message.');
  }
});

module.exports = router;
