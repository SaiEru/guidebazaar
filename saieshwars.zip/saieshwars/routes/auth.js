const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user');

const router = express.Router();

// Redirect root to login
router.get('/', (req, res) => {
  res.redirect('/login');
});

// Show login page
router.get('/login', (req, res) => {
  res.render('login', { showHomeButton: false });
});

// Handle login form submission
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (email === 'erukullasai0@gmail.com' && password === 'admin123') {
    res.redirect('/admininterface');
  } else {
    res.render('login', { showHomeButton: true });
  }
});
// User Registration
router.post('/register', async (req, res) => {
  const { email, password } = req.body;

  // Check if the user already exists in the database
  const existingUser = await User.findOne({ email });
  if (existingUser) {
    return res.render('login', { showHomeButton: false, error: 'Email already exists' });
  }

  // Hash the password before saving
  const hashedPassword = await bcrypt.hash(password, 10);

  // Create and save new user
  const newUser = new User({
    email,
    password: hashedPassword,
  });

  await newUser.save();

  return res.redirect('/login');
});

// User Login
router.post('/userlogin', async (req, res) => {
  const { email, password } = req.body;

  // Find user in the database
  const user = await User.findOne({ email });

  if (!user) {
    return res.render('login', { showHomeButton: false, error: 'Invalid email or password' });
  }

  // Compare the entered password with the stored hashed password
  const isMatch = await bcrypt.compare(password, user.password);

  if (!isMatch) {
    return res.render('login', { showHomeButton: false, error: 'Invalid email or password' });
  }

  // Generate JWT token
  const token = jwt.sign({ email: user.email }, 'secretkey', { expiresIn: '1d' });

  // Send JWT token to client
  res.cookie('token', token, { httpOnly: true }); // Store token in HTTP-only cookie for security

  // Redirect to home or user dashboard
  res.redirect('/home');
});
// Admin interface
router.get('/admininterface', (req, res) => {
  res.render('admininterface');
});

// Middleware to verify JWT token
const authenticateJWT = (req, res, next) => {
  const token = req.cookies.token; // Get the token from the cookie

  if (!token) {
    return res.redirect('/login'); // Redirect to login if no token is found
  }

  // Verify the token
  jwt.verify(token, 'secretkey', (err, decoded) => {
    if (err) {
      return res.redirect('/login'); // Redirect to login if token verification fails
    }

    req.user = { email: decoded.email }; // Attach the decoded user data to the request object
    next(); // Continue to the next middleware/route handler
  });
};

// User home route with JWT authentication
router.get('/home', authenticateJWT, (req, res) => {
  // Pass the user's email to home.ejs view
  res.render('home', { userEmail: req.user ? req.user.email : null });
});

module.exports = router;
