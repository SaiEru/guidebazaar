// routes/blog.js
const express = require('express');
const router = express.Router();
const Blog = require('../models/Blog');
const jwt = require('jsonwebtoken');
// Route to display the 'Create New Blog' form (GET request)
router.get('/create', (req, res) => {
  res.render('blog'); // Renders the blog.ejs view
});

// Route to handle the POST request from the 'Create Blog' form
router.post('/create', async (req, res) => {
  const { title, content, category, name, email } = req.body;

  try {
    const newBlog = new Blog({ title, content, category, name, email });
    await newBlog.save();
    res.redirect('/blog'); // Redirect to the blog list after saving
  } catch (err) {
    console.error(err);
    res.status(500).send('Error saving blog');
  }
});

// Route to view a single blog's details
router.get('/:id', async (req, res) => {
  let userEmail = null;

  // Check if there's a token and decode it
  try {
    const token = req.cookies.token;
    if (token) {
      const decoded = jwt.verify(token, 'secretkey'); // Ensure to use your actual secret key here
      userEmail = decoded.email;
    }
  } catch (err) {
    // ignore JWT errors for public access
  }

  try {
    const blog = await Blog.findById(req.params.id);
    if (!blog) {
      return res.status(404).send('Blog not found');
    }

    // Render the blog details page and pass the blog and userEmail
    res.render('blog-details', { blog, userEmail });
  } catch (err) {
    res.status(400).send('Invalid blog ID');
  }
});

router.get('/blog', async (req, res) => {
  try {
    const category = req.query.category;
    let blogs;

    if (category) {
      // If category is provided, filter blogs by the selected category
      blogs = await Blog.find({ category: category });
    } else {
      // Otherwise, show all blogs
      blogs = await Blog.find();
    }

    // Render the page with the filtered blogs
    res.render('blog', { blogs });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error retrieving blogs');
  }
});
router.get('/events', async (req, res) => {
  let userEmail = null;

  try {
    const token = req.cookies.token;
    if (token) {
      const decoded = jwt.verify(token, 'secretkey');
      userEmail = decoded.email;
    }
  } catch (err) {
    // ignore JWT errors for public access
  }

  try {
    // If you have an Event model, you could fetch events from the DB
    // const events = await Event.find().sort({ date: 1 }); 

    res.render('events', {
      // events, // include this if you're rendering from DB
      userEmail
    });
  } catch (err) {
    res.status(500).send('Failed to load events');
  }
});

// Route to list all blogs (GET request)
router.get('/', async (req, res) => {
  let userEmail = null;

  try {
    const token = req.cookies.token;
    if (token) {
      const decoded = jwt.verify(token, 'secretkey');
      userEmail = decoded.email;
    }
  } catch (err) {
    // ignore JWT errors for public access
  }

  try {
    const blogs = await Blog.find().sort({ createdAt: -1 });

    res.render('blog', {
      blogs,
      userEmail // 👈 passed to EJS template
    });
  } catch (err) {
    res.status(500).send('Failed to load blogs');
  }
});
module.exports = router;
