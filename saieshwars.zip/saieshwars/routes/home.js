const express = require('express');
const router = express.Router();

// GET /home - Render home.ejs
router.get('/home', (req, res) => {
  res.render('home'); // Make sure views/home.ejs exists
});

module.exports = router;
