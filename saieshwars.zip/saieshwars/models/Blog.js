// models/Blog.js
const mongoose = require('mongoose');

// Define the Blog schema
const blogSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  content: {
    type: String,
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
}, { timestamps: true });  // Automatically adds createdAt and updatedAt fields

// Create a model for Blog
const Blog = mongoose.model('Blog', blogSchema);

module.exports = Blog;
