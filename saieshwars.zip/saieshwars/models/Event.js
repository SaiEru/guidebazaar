const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: String,
  description: String,
  date: String,
  time: String,
  location: String,
  category: String,
  zoomLink: String
});

module.exports = mongoose.model('Event', eventSchema);
