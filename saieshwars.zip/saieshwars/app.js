require('dotenv').config();
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');
const app = express();

app.use(cookieParser());
// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middlewares
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));

// Routes
const authRoutes = require('./routes/auth');
const eventRoutes = require('./routes/events');
const blogRoutes = require('./routes/blog'); // This is already imported above, no need to import it twice
const homeRoute = require('./routes/home');
// Login is now the main entry point
app.use('/', authRoutes);

// Other routes
app.use('/events', eventRoutes);
app.use('/blog', blogRoutes);
app.use('/home', homeRoute);


// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
